# Switching from Hub-and-Spoke to Shared-Context Mesh

## When to Switch

Switch when all three of these are true:
1. The Architect's task breakdown is stable (no major restructuring needed)
2. Agents are producing well-formed outputs consistently
3. You want to move faster and reduce relay overhead

## How to Switch

### Step 1 -- Collect the Full Context Log
Gather every output block from the session so far into a single document:
- All ARCHITECT_PLAN versions
- All RESEARCH_REPORTs
- All BUILD_STATUS and DELIVERABLE blocks
- Any CONFLICT_FLAG or BLOCKER resolutions

### Step 2 -- Swap System Prompts
Replace each agent's Hub system prompt with the corresponding Mesh prompt from `/prompts/mesh/`.

### Step 3 -- Reissue the Brief
Send a new message to all three agents:

```
## MODEL UPGRADE NOTICE

This session is switching from Hub-and-Spoke to Shared-Context Mesh.

Your role remains the same. Key change: you now read all peer outputs
directly from the shared context log below. The human coordinator will
approve actions via PROPOSAL and BUILD_STATUS blocks before you execute.

## SHARED_CONTEXT LOG (all prior outputs)
[paste the full context log from Step 1]

## CURRENT TASK STATUS
[paste the latest ARCHITECT_PLAN with updated statuses]
```

### Step 4 -- Confirm Each Agent Acknowledges
Wait for each agent to confirm they have read the shared context log and understand the new model. They should emit a brief acknowledgment, not a full re-plan.

### Step 5 -- Resume Normal Mesh Workflow
Continue from Step 4 of the Mesh workflow (Architect proposes actions).
