# Orchestr8 Workflow Guide

## Hub-and-Spoke: Step-by-Step

### Step 1 -- Broadcast Brief
Paste the PROJECT_BRIEF into all 3 agent windows simultaneously. Don't wait for one to finish before sending to the others.

### Step 2 -- Architect Plans
Architect returns an ARCHITECT_PLAN JSON block. Review it for accuracy, reasonable task breakdown, and correct vocabulary definitions.

### Step 3 -- Relay Plan
Copy the ARCHITECT_PLAN and paste it into the Researcher and Builder chats. Include a brief note: "Here is the Architect's plan. Please respond with your respective output."

### Step 4 -- Parallel Responses
Researcher returns a RESEARCH_REPORT. Builder returns a BUILD_STATUS. Both reference task IDs from the plan.

### Step 5 -- Cross-Feed Outputs
Share each agent's output with the other two. Trim to the sections relevant to their role. Don't dump everything -- agents work better with focused context.

### Step 6 -- Conflict Resolution
If any agent emits a CONFLICT_FLAG or BLOCKER, route it to the Architect for resolution. Include the conflicting outputs so the Architect can see both sides.

### Step 7 -- Build Loop
Builder delivers versioned DELIVERABLEs. Route to Architect for review. Architect emits APPROVED or REVISION_REQUEST. Relay critique back to Builder. Iterate until approved.

---

## Shared-Context Mesh: Step-by-Step

### Step 1 -- Broadcast + Open Shared Log
Send the PROJECT_BRIEF to all agents. Include the same SHARED_CONTEXT block so every agent starts with the same information.

### Step 2 -- Plan Written to Log
Architect emits ARCHITECT_PLAN into the shared log. All agents see it immediately -- no relay needed from you.

### Step 3 -- Parallel Reactions
Researcher and Builder read the plan directly from the log and respond simultaneously. Researcher emits RESEARCH_REPORT. Builder emits BUILD_STATUS.

### Step 4 -- Architect Proposes Actions
Architect reads peer outputs from the log and emits PROPOSAL blocks targeting specific agents with specific actions.

### Step 5 -- Approval Gate (Your Key Role)
YOU review all PROPOSAL and BUILD_STATUS blocks. For each one:
- **Approve** -- the targeted agent proceeds
- **Edit** -- modify the proposal and then approve
- **Reject** -- explain why and ask for a revised proposal

### Step 6 -- Approved Execution
Builder receives your APPROVED signal and emits a DELIVERABLE with citations showing which peer outputs informed the approach.

### Step 7 -- Peer Review Loop
Agents emit PEER_REVIEW blocks on each other's outputs. You triage: decide what's actionable vs. noise. Route actionable reviews back to the originating agent.

---

## Switching from Hub to Mesh Mid-Project

See [switching-models.md](./switching-models.md) for the step-by-step process.

---

## Efficiency Patterns

**Parallel bootstrap** -- Send the brief to all three agents at once. Architect builds the plan, Researcher pre-loads context, Builder lists clarifying questions. All at once.

**JSON is the lingua franca** -- Copy-paste between windows. The format handles the translation.

**One task per message** -- When relaying, include only what's relevant to that agent's next task. Trim aggressively.

**Version your deliverables** -- Ask Builder to tag outputs as v0.1, v0.2. Reference the version when routing critiques.

**Conflict detection is your job (Hub)** -- Read both sides before relaying. State conflicts explicitly.

**Watch for echo chambers (Mesh)** -- Agents can reinforce each other's wrong assumptions. Read PEER_REVIEW blocks critically.
