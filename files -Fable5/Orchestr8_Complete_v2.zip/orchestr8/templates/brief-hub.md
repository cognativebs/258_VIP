## PROJECT_BRIEF

**Session ID:** [e.g., PROJ-2026-001]
**Model:** Hub-and-Spoke (you relay all messages)
**Human Coordinator:** [Your name]
**Schema Version:** 1.0

---

### Goal
[1-3 sentences. What are we building or solving? What does success look like?]

### Context
[Background the agents need. Tech stack, constraints, existing work, target users.]

### Deliverables Expected
- [ ] [e.g., Working prototype]
- [ ] [e.g., Architecture decision record]
- [ ] [e.g., Research summary]

### Constraints
- Time: [deadline or sprint length]
- Tech: [languages, platforms, APIs available]
- Budget/Resources: [any limits]

### Agent Configuration
- Architect: [model, e.g., Claude Opus 4.6]
- Researcher: [model, e.g., GPT-5.4]
- Builder: [model, e.g., Claude Sonnet 4.6]

### Your Role as Human Coordinator (Message Bus)
You will:
1. Copy the ARCHITECT_PLAN and paste it into Researcher and Builder
2. Copy RESEARCH_REPORT and paste it into Architect and Builder
3. Copy BUILD_STATUS and paste it into Architect and Researcher
4. Relay CONFLICT_FLAG and BLOCKER messages to the Architect
5. Make final decisions when agents disagree
