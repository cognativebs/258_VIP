## PROJECT_BRIEF

**Session ID:** [e.g., PROJ-2026-001]
**Model:** Shared-Context Mesh (agents read shared log, you approve actions)
**Human Coordinator:** [Your name]
**Schema Version:** 1.0

---

### Goal
[1-3 sentences. What are we building or solving? What does success look like?]

### Context
[Background the agents need. Tech stack, constraints, existing work, target users.]

### Deliverables Expected
- [ ] [e.g., Working prototype]
- [ ] [e.g., Architecture decision record]
- [ ] [e.g., Research summary]

### Constraints
- Time: [deadline or sprint length]
- Tech: [languages, platforms, APIs available]
- Budget/Resources: [any limits]

### Agent Configuration
- Architect: [model, e.g., Claude Opus 4.6]
- Researcher: [model, e.g., GPT-5.4]
- Builder: [model, e.g., Claude Sonnet 4.6]

### Your Role as Human Coordinator (Approval Gate)
You will:
1. Maintain and share the SHARED_CONTEXT log with all agents
2. Review all PROPOSAL blocks before any agent acts
3. Approve, edit, or reject BUILD_STATUS before Builder executes
4. Triage PEER_REVIEW blocks and decide what gets addressed
5. Resolve escalated CONFLICT_FLAG blocks
