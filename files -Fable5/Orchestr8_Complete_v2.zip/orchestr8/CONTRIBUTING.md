# Contributing to Orchestr8

Thanks for your interest in contributing. Here's how to help.

## What we need most

- **Additional agent roles** -- QA, Designer, DevOps, PM. Each needs a system prompt for both Hub and Mesh models.
- **Example session logs** -- Run a real project through the workflow and record the full session. The more diverse the better.
- **Block validation tooling** -- CLI or library that validates JSON blocks against /schemas/blocks.json.
- **Provider API adapters** -- Proxy adapters for additional providers beyond Anthropic, OpenAI, and Google.
- **Documentation improvements** -- Clearer explanations, more examples, better diagrams.

## How to contribute

1. Fork the repo
2. Create a branch (`git checkout -b feature/your-feature`)
3. Make your changes
4. Run any existing tests
5. Submit a PR with a clear description

## Style guide

- System prompts use `--` for dashes (safe across tokenizers)
- JSON schemas follow JSON Schema 2020-12
- Documentation is Markdown with no HTML
- Keep prompts model-agnostic -- they should work with any provider

## Code of conduct

Be kind. Be constructive. We're all building together.
