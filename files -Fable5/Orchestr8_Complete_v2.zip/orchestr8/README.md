# Orchestr8

**A human-supervised framework for coordinating multiple AI agents across any project.**

Stop copy-pasting between chat windows. Give every agent a role, a typed output format, and a shared vocabulary -- then stay in control of every decision that matters.

---

## The problem it solves

When you run a project across Claude, GPT-5, and Gemini simultaneously, things fall apart fast:

- Context gets lost between windows
- Agents contradict each other and you don't catch it until it's too late
- There's no record of what was decided or why
- You spend more time managing AI than building

Orchestr8 gives you a structured coordination layer: typed message blocks, defined agent roles, and a human approval gate on every consequential action.

---

## Two coordination models

### 🕸️ Hub-and-Spoke
**You are the message bus.**

Agents are completely isolated from each other. Every output routes through you before any other agent sees it. Maximum control, zero context bleed.

Best for: new projects, high-stakes decisions, learning the workflow.

```
Architect ──→ You ──→ Researcher
                 ↘         ↓
                   Builder ←┘
```

### 🔗 Shared-Context Mesh
**You are the approval gate.**

All agents read from a shared context log and react to each other's outputs proactively. You don't relay -- you review and approve before anything executes.

Best for: mature projects, trusted agent roles, moving fast.

```
         ┌──────────────────┐
         │  SHARED LOG      │
         │  Architect        │
         │  Researcher       │
         │  Builder          │
         └────────┬─────────┘
                  ↓
            ⚠️  YOU
          (approve / edit / reject)
```

You can switch between models mid-project. See [switching models](docs/switching-models.md).

---

## The three agents

| Agent | Recommended Model (June 2026) | Role | Key Output |
|-------|-------------------------------|------|------------|
| 🏗️ Architect | Claude Opus 4.6+ / GPT-5.5 | Plan, decompose, resolve conflicts | `ARCHITECT_PLAN` |
| 🔬 Researcher | GPT-5.4 / Gemini 2.5 Pro | Research, validate, fill gaps | `RESEARCH_REPORT` |
| ⚙️ Builder | Claude Sonnet 4.6 / GPT-5.4 Mini | Write code, produce deliverables | `DELIVERABLE` |

Agents are model-agnostic. These are recommendations, not requirements. Use whatever models your API keys support.

---

## Authentication: Bring Your Own Key (BYOK)

Orchestr8 does **not** log into your Claude, GPT, or Gemini account on your behalf. All major AI providers [banned OAuth passthrough for third-party tools](https://aihackers.net/posts/anthropic-claude-code-oauth-policy-feb-2026/) in early 2026.

Instead, you **bring your own API keys**:

1. Create a developer account at each provider's console
2. Generate an API key
3. Paste it into Orchestr8's settings

Your keys are encrypted at rest and only used server-side to proxy requests to each provider's API. Orchestr8 never sees your provider password or subscription credentials.

**Supported providers:**
- [Anthropic Console](https://console.anthropic.com) → Claude models
- [OpenAI Platform](https://platform.openai.com) → GPT-5.x, o3 models
- [Google AI Studio](https://aistudio.google.com) → Gemini 2.5 models
- AWS Bedrock → Claude + other models via AWS
- Google Vertex AI → Gemini via GCP

---

## Typed message blocks

All communication is structured JSON. 11 block types. The format is the handoff -- no translation needed.

### Universal (both models)

| Block | Purpose |
|-------|---------|
| `ARCHITECT_PLAN` | Goal, task breakdown, shared vocabulary, risks |
| `RESEARCH_REPORT` | Findings with confidence levels, validated/challenged assumptions |
| `BUILD_STATUS` | Tasks accepted/deferred, approach summary, approval request |
| `DELIVERABLE` | Versioned output with notes |
| `CONFLICT_FLAG` | Contradiction detected between outputs, with suggested resolution |
| `BLOCKER` | Can't proceed without X, escalated to human |

### Mesh-only

| Block | Purpose |
|-------|---------|
| `PROPOSAL` | Architect proposes action targeting another agent; awaits human approval |
| `PEER_REVIEW` | Agent reviews another's output; verdict: APPROVED / CONCERN / CONFLICT |

### Operational

| Block | Purpose |
|-------|---------|
| `PROVIDER_ERROR` | API call to a provider failed (emitted by platform) |
| `HUMAN_NOTE` | Human adds context without triggering a formal agent output cycle |
| `TASK_REASSIGN` | Human moves a task from one agent to another |

Full JSON Schema: [`/schemas/blocks.json`](schemas/blocks.json)

---

## Quickstart

### 1. Pick your model

Decide whether you're running Hub-and-Spoke (relay everything) or Shared-Context Mesh (approve everything). Start with Hub-and-Spoke if this is your first session.

### 2. Apply system prompts

Copy the system prompt for each agent from [`/prompts`](prompts/) into a separate chat window:

```
prompts/
  hub/
    architect.md     ← Claude Opus or GPT-5.5
    researcher.md    ← GPT-5.4 or Gemini 2.5 Pro
    builder.md       ← Claude Sonnet or GPT-5.4 Mini
  mesh/
    architect.md
    researcher.md
    builder.md
```

### 3. Fill the project brief

Copy the brief template from [`/templates`](templates/), fill it in, and paste it into all three agent windows.

### 4. Start coordinating

Follow the 7-step loop for your model. See the [workflow guide](docs/workflow.md).

---

## Project structure

```
orchestr8/
├── prompts/
│   ├── hub/
│   │   ├── architect.md
│   │   ├── researcher.md
│   │   └── builder.md
│   └── mesh/
│       ├── architect.md
│       ├── researcher.md
│       └── builder.md
├── templates/
│   ├── brief-hub.md
│   └── brief-mesh.md
├── schemas/
│   └── blocks.json            # JSON Schema for all 11 block types
├── docs/
│   ├── workflow.md             # Full step-by-step for both models
│   └── switching-models.md     # How to upgrade Hub → Mesh mid-project
└── README.md
```

---

## Why human-in-the-loop?

Current multi-agent frameworks (LangChain, CrewAI, AutoGen) optimize for automation. Agents talk to each other, chain tools, and execute autonomously.

That's great for well-defined, low-stakes pipelines. It's a problem for creative and strategic work, where:

- The requirements are ambiguous
- A wrong assumption from Agent A will be amplified by Agents B and C
- You need to understand *why* a decision was made, not just what was produced
- The work involves judgment calls that shouldn't be automated away

Orchestr8 keeps you in the loop not as a bottleneck, but as the only entity with full context. The agents are faster than you. You're smarter about the goal than they are. This framework plays to both strengths.

---

## Hosted app

The framework is free and open-source (MIT). A hosted web app with session management, BYOK key vault, approval queue UI, shared context log, block validation, and audit export is coming.

→ **[Join the waitlist](https://orchestr8.dev)**

---

## Contributing

Issues and PRs welcome. The most useful contributions right now:

- Additional agent roles (QA, Designer, DevOps)
- Example session logs for different project types
- Block validation tooling
- Provider-specific API proxy adapters

---

## License

MIT. Use it, fork it, build on it.
